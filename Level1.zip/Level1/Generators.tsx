<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Generators" tilewidth="32" tileheight="16" tilecount="4" columns="4">
 <image source="generator1-sheet.png" width="128" height="16"/>
</tileset>
